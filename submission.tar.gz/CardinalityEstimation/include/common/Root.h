//
// Don't modify this file, the evaluation program is compiled
// based on this header file.
//

#ifndef CARDINALITYESTIMATION_ROOT
#define CARDINALITYESTIMATION_ROOT

#include <vector>
#include <set>
#include <map>
#include <cmath>
#include <chrono>
#include <random>
#include <algorithm>
#include <stdlib.h>
#include <unordered_map>
#include <utility>
#include <iostream>
#include <ostream>

#endif
